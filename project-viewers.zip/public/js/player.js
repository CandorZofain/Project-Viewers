"use strict"
const REPAIR_COST = 50;
const REPAIR_AMOUNT = 10;

var Player = function () {
    let battleData = {
        elementMult: 2,
        dmgMult: 5
    };

    this.ableToMove = false;

    this.StartTurn = function () {
        this.ableToMove = true;
        map.RemoveMenu();
    }

    this.HandleHexData = function (position) {
        map.StartOpenTab(document.getElementById('space-data-tab'));
        let space = gameState.spaces[position[0]][position[1]];
        let data = [space.occupants.length, '?', '?', '?', '?', '?'];
        if (space.team == 0 || space.team == gameState.user.team) {
            data = [space.occupants.length, 0, 0, 0, 0, 0];
            space.occupants.forEach(playerId => {
                const player = gameState.teamMembers[playerId];
                switch (player.element) {
                    case 'neutral':
                        data[1]++;
                        break;
                    case 'fire':
                        data[2]++;
                        break;
                    case 'water':
                        data[3]++;
                        break;
                    case 'wind':
                        data[4]++;
                        break;
                    case 'earth':
                        data[5]++;
                        break;
                    default:
                        global.Error(`Unknown element: ${player.element}`);
                        break;
                }
            });
            if (data.reduce((total, num) => { return total + num; }) / 2 != data[0]) {
                global.Error('Space elements do not sum to total');
            }
        }

        Object.keys(gameState.team).forEach(teamNum => {
            let team = gameState.team[teamNum];
            if (JSON.stringify(team.position) == JSON.stringify(position)) {
                data[6] = team.hp;
            }
        });

        map.UpdateSpaceTab(data);

        if (!this.ableToMove) {
            global.Log('Not allowed to move');
            return;
        }

        let user = gameState.user;
        let xDiff = position[0] - user.position[0];
        let yDiff = position[1] - user.position[1];
        if (xDiff == 0 && yDiff == 0) {
            // Selected current position
            switch (space.type) {
                case 0:
                    map.CreateMenu(`
                        <button onclick='player.Defend()' type='button'>Defend</button>
                    `);
                    break;
                case 1:
                    let repair = user.crystals >= REPAIR_COST ? '' :
                        `disabled title='Need ${REPAIR_COST} crystals'`;
                    let element = user.crystals > 0 ? '' :
                        `disabled title='Need crystals to change element'`;
                    map.CreateMenu(`
                        <button onclick='player.Defend()' type='button'>Defend</button>
                        <button ${repair} onclick='player.Repair()' type='button'>Repair</button>
                        <button ${element} onclick='player.ChangeElementOptions()' type='button'>Element</button>
                    `);
                    break;
                case 2:
                    map.CreateMenu(`
                        <button onclick='player.Defend()' type='button'>Defend</button>
                        <button onclick='player.Gather()' type='button'>Gather</button>
                    `);
                    break;
                default:
                    global.Error(`Unknown hexagon type: ${space.type}`);
                    break;
            }
        } else if (
            Math.abs(xDiff) <= 1 &&
            Math.abs(yDiff) <= 1 &&
            Math.abs(xDiff + yDiff) <= 1
        ) {
            if (space.team == user.team || space.team == 0) {
                map.CreateMenu(`
                    <button onclick='player.Move(${JSON.stringify(position)})' type='button'>Move</button>
                `);
            } else {
                map.CreateMenu(`
                    <button onclick='player.Move(${JSON.stringify(position)})' type='button'>Attack</button>
                `);
            }
        }
    };

    this.Defend = function () {
        this.ableToMove = false;

        map.RemoveMenu();

        socket.send(JSON.stringify({
            event: 'defend',
            Authorization: auth
        }));
    };

    this.Gather = function () {
        this.ableToMove = false;

        map.RemoveMenu();

        socket.send(JSON.stringify({
            event: 'gather',
            Authorization: auth
        }));
    };

    this.Repair = function () {
        this.ableToMove = false;

        map.RemoveMenu();

        socket.send(JSON.stringify({
            event: 'repair',
            Authorization: auth
        }));
    };

    this.ChangeElementOptions = function () {
        map.RemoveMenu();
        map.CreateMenu(`
            <button onclick='player.ChangeElement("earth")' type='button'>Earth</button>
            <button onclick='player.ChangeElement("fire")' type='button'>Fire</button>
            <button onclick='player.ChangeElement("water")' type='button'>Water</button>
            <button onclick='player.ChangeElement("wind")' type='button'>Wind</button>
        `)
    };
    this.ChangeElement = function (element) {
        map.RemoveMenu();

        gameState.user.element = element;
        map.UpdatePlayerTab();

        socket.send(JSON.stringify({
            event: 'changeElement',
            data: element,
            Authorization: auth
        }));
    }

    this.Move = function (newPos) {
        this.ableToMove = false;

        map.RemoveMenu();

        socket.send(JSON.stringify({
            event: 'move',
            data: newPos,
            Authorization: auth
        }));
    };
};